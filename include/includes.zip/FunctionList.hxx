// Update functions
#include "TMVA/RFunction_MLP.hxx"

// Aggregate functions
#include "TMVA/RFunction_Sum.hxx"
#include "TMVA/RFunction_Mean.hxx"
