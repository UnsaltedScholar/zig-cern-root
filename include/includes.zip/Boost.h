// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_Boost
#define ROOT_Math_Boost


#include "Math/GenVector/Boost.h"


#endif
