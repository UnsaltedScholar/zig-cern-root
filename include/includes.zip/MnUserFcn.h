#ifndef ROOT_Minuit2_MnUserFcn
#define ROOT_Minuit2_MnUserFcn

#include <Minuit2/MnFcn.h>

namespace ROOT {
namespace Minuit2 {

using MnUserFcn = MnFcn;

}
} // namespace ROOT

#endif
