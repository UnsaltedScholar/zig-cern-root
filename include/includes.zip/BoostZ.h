// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_BoostZ
#define ROOT_Math_BoostZ


#include "Math/GenVector/BoostZ.h"


#endif
