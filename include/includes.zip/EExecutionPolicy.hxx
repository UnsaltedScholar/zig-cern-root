#ifndef ROOT_Internal_ExecutionPolicy
#define ROOT_Internal_ExecutionPolicy

namespace ROOT {
enum class EExecutionPolicy { kSequential, kMultiThread, kMultiProcess };
}

#endif
