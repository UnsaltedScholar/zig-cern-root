// @(#)root/mathcore:$Id$
// Authors: W. Brown, M. Fischler, L. Moneta    2005

#ifndef ROOT_Math_BoostX
#define ROOT_Math_BoostX


#include "Math/GenVector/BoostX.h"


#endif
